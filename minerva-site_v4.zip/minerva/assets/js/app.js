const KEY='verifica_historico';
function getHist(){try{const v=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(v)?v:[]}catch(e){return[]}}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function analisar(texto,fonte){
  const t=texto.toLowerCase();let s=60;const sinais=[];
  const alarm=['urgente','compartilhe','antes que apaguem','100%','milagre','cura','chocante','ninguém está falando','governo esconde','!!!'];
  alarm.forEach(w=>{if(t.includes(w)){s-=12;sinais.push('Linguagem sensacionalista: "'+w+'"')}});
  if((texto.match(/[A-ZÁÉÍÓÚ]{5,}/g)||[]).length>2){s-=10;sinais.push('Uso excessivo de letras maiúsculas')}
  const conf=['g1','folha','estadao','bbc','uol','agência brasil','gov.br','reuters','who.int','fiocruz'];
  if(fonte&&conf.some(c=>fonte.toLowerCase().includes(c))){s+=25;sinais.push('Fonte reconhecida e confiável')}
  else if(fonte){s-=5;sinais.push('Fonte não reconhecida — confira em outros veículos')}
  else{s-=10;sinais.push('Nenhuma fonte informada')}
  if(/\d{4}|segundo|de acordo com|pesquisa|estudo/.test(t)){s+=10;sinais.push('Cita dados, datas ou estudos')}
  if(texto.length<60){s-=8;sinais.push('Texto muito curto, pouco contexto')}
  s=Math.max(3,Math.min(97,s));
  const v=s>=65?'Provavelmente verdadeira':s>=40?'Duvidosa':'Provavelmente falsa';
  const cls=s>=65?'v-true':s>=40?'v-mid':'v-false';
  return{score:s,veredito:v,cls,sinais};
}
function verificar(e){
  e.preventDefault();
  const texto=document.getElementById('texto').value.trim();
  const fonte=document.getElementById('fonte').value.trim();
  const cat=document.getElementById('categoria').value;
  if(!texto)return;
  const r=analisar(texto,fonte);
  const h=getHist();h.unshift({id:Date.now(),texto,fonte,cat,data:new Date().toLocaleString('pt-BR'),...r});
  localStorage.setItem(KEY,JSON.stringify(h));
  const box=document.getElementById('resultado');
  const map={c1:['Confiabilidade',r.score+'%',r.score],c2:['Linguagem',r.sinais.some(x=>x.includes('sensacional'))?'Alarmista':'Neutra',r.sinais.some(x=>x.includes('sensacional'))?25:85],c3:['Fonte',fonte?fonte:'Não informada',r.sinais.some(x=>x.includes('confiável'))?90:fonte?45:15],c4:['Evidências',r.sinais.some(x=>x.includes('dados'))?'Presentes':'Ausentes',r.sinais.some(x=>x.includes('dados'))?80:30]};
  box.innerHTML=`<div class="panel"><div class="verdict">${r.veredito}</div><ul style="margin-left:20px">${r.sinais.map(s=>'<li>'+esc(s)+'</li>').join('')}</ul></div><div class="grid2">${Object.values(map).map(([t,d,p])=>`<div class="card"><div class="head">${t}<span class="ic">✓</span></div><p>${esc(d)}</p><div class="bar"><i style="width:0" data-w="${p}"></i></div></div>`).join('')}</div>`;
  box.classList.add('show');
  setTimeout(()=>box.querySelectorAll('.bar i').forEach(i=>i.style.width=i.dataset.w+'%'),50);
}
function renderHist(){
  const g=document.getElementById('lista');if(!g)return;
  const q=(document.getElementById('busca').value||'').toLowerCase();
  const fv=document.getElementById('fv').value,fc=document.getElementById('fc').value,fo=document.getElementById('fo').value;
  let h=getHist().filter(x=>x.texto.toLowerCase().includes(q)&&(!fv||x.cls===fv)&&(!fc||x.cat===fc));
  if(fo==='antigas')h.reverse();
  g.innerHTML=h.length?h.map(x=>`<div class="hcard"><h3><span></span>${x.veredito}</h3><p style="font-size:14px">${esc(x.texto.slice(0,90))}${x.texto.length>90?'…':''}</p><div class="tags"><span class="tag">${esc(x.cat)}</span><span class="tag">${esc(x.data)}</span></div><span class="badge ${x.cls}">${x.score}% confiável</span></div>`).join(''):'<p class="empty" style="grid-column:1/-1">Nenhuma verificação encontrada. <a class="btn cyan" href="verificador.html">Verificar uma notícia</a></p>';
}
function limpar(){if(confirm('Apagar todo o histórico?')){localStorage.removeItem(KEY);renderHist()}}
